<!-- Jquery Slim JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/jquery.min.js"></script>
<!-- Bootstrap JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/bootstrap.bundle.min.js"></script>
<!-- Meanmenu JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/jquery.meanmenu.js"></script>
<!-- Owl Carousel JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/owl.carousel.min.js"></script>
<!-- Magnific Popup JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/jquery.magnific-popup.min.js"></script>
<!-- Imagelightbox JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/imagelightbox.min.js"></script>
<!-- Odometer JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/odometer.min.js"></script>
<!-- Jquery Appear JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/jquery.appear.min.js"></script>
<!-- Ajaxchimp JS -->
<!-- <script src="<?= base_url() ?>/theme/ketan/assets/js/jquery.ajaxchimp.min.js"></script> -->
<!-- Form Validator JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/form-validator.min.js"></script>
<!-- Contact JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/contact-form-script.js"></script>
<!-- Custom JS -->
<script src="<?= base_url() ?>/theme/ketan/assets/js/main.js"></script>
</body>

<!-- Mirrored from templates.envytheme.com/ketan/default/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 20 Feb 2023 02:38:24 GMT -->

</html>