<input type="hidden" name="jawaban" value="<?= $jawaban ?>">
<input type="hidden" name="id" value="<?= $id ?>">
<div class="content" style="margin: 15px;">
    <a href="#" class="optional-btn">
        <h3><?= $angka1 ?> + <?= $angka2 ?> = <?= $hasil ?></h3>
    </a>
</div>