<!doctype html>
<html lang="zxx" class="theme-light">

<!-- Mirrored from templates.envytheme.com/ketan/default/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 20 Feb 2023 02:38:19 GMT -->

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/bootstrap.min.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/animate.min.css">
    <!-- Meanmenu CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/meanmenu.css">
    <!-- Boxicons CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/boxicons.min.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/owl.carousel.min.css">
    <!-- Owl Carousel Default CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/owl.theme.default.min.css">
    <!-- Odometer CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/odometer.min.css">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/magnific-popup.min.css">
    <!-- Imagelightbox CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/imagelightbox.min.css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/style.css">
    <!-- Dark CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/dark.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/theme/ketan/assets/css/responsive.css">

    <title>Tes Pauli</title>

    <link rel="icon" type="image/png" href="<?= base_url() ?>/theme/ketan/assets/img/favicon.png">
</head>

<body>